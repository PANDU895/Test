package org.apache.commons.net.ftp;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;



public class TestSort {

	public static void main(String[] args) {
		List<Emp> list = new ArrayList<Emp>();
		
		list.add(new Emp("Srikanth", "Parimi", 29, "Cap"));
		list.add(new Emp("manoj", "prabhakar", 28, "infi"));
		list.add(new Emp("aaa", "swew", 50, "xxss"));
		Collections.sort(list);
		System.out.println("based on first name name->"+list.toString());
	}

}
